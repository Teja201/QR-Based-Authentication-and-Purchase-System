package com.DAO;

import java.util.List;

import com.entity.Book_dtls;

public interface BookDAO {
	public boolean addBooks(Book_dtls b);
	public List<Book_dtls> getAllBooks();
	public Book_dtls getBookById(int id);
	public boolean updateEditBooks(Book_dtls b);
	public boolean deleteBooks(int id);
}
